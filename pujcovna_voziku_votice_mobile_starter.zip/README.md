# Půjčovna vozíků Votice – mobilní aplikace

Expo / React Native starter for iPhone and Android.

## Included
- Dark black/yellow customer interface
- Neptun and Agados trailers (202 × 114 cm, 750 kg)
- Prices: 200 Kč / 4 hours, 300 Kč / 24 hours, 450 Kč / weekend Friday–Sunday
- Booking request form, owner approval status flow
- Cash or bank transfer on pickup; no deposit
- Contact: 725 186 541 and martin.placa.placek@gmail.com
- Optional Supabase data adapter and initial SQL schema

## Important current limitation
This is a starter project, not a deployed app. Without Supabase configuration it deliberately runs in demo mode and does not transmit or persist bookings. The included admin screen is not yet protected by owner authentication and must not be exposed as a production admin panel. Push notifications and email notifications are not wired yet.

## Run locally
1. Install Node.js LTS.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and fill in the Supabase project URL and anon key after creating a Supabase project.
4. Run `npx expo start`.
5. Scan the QR code using Expo Go on your iPhone, or use an Android device/emulator.

## Backend setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Add `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY` to `.env`.
4. Before public launch, implement Supabase Auth and restrictive Row Level Security policies. Do not make the reservations table publicly readable.
5. Add server-side email notification (e.g. Supabase Edge Function + email provider) and Expo push notification registration after owner authentication is in place.

## Store publishing
Publishing requires Apple Developer and Google Play developer accounts, store assets, privacy disclosures, and production builds. App Store / Play Store submission is not included in this source archive.
