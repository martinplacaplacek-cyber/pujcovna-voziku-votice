import React, { useEffect, useState } from 'react';
import { Alert, Linking, SafeAreaView, ScrollView, StatusBar, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { supabase } from './src/supabase';

const Y = '#FACC15', BG = '#101010', PANEL = '#202020', MUTED = '#AAAAAA';
const trailers = [
  { id: 'neptun', name: 'Neptun', dimensions: '202 × 114 cm', capacity: '750 kg' },
  { id: 'agados', name: 'Agados', dimensions: '202 × 114 cm', capacity: '750 kg' },
];
const rates = [{ label: '4 hodiny', price: 200 }, { label: '24 hodin', price: 300 }, { label: 'Víkend (pátek–neděle)', price: 450 }];

export default function App() {
  const [tab, setTab] = useState<'home'|'trailers'|'booking'|'admin'>('home');
  const [trailer, setTrailer] = useState('neptun');
  const [rate, setRate] = useState(0);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('09:00');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [payment, setPayment] = useState('Hotově při převzetí');
  const [requests, setRequests] = useState<any[]>([]);
  const [connected, setConnected] = useState(false);

  useEffect(() => { loadRequests(); }, []);
  async function loadRequests() {
    if (!supabase) return;
    const { data, error } = await supabase.from('reservations').select('*').order('created_at', { ascending: false });
    if (!error && data) { setRequests(data); setConnected(true); }
  }
  async function submit() {
    if (!name.trim() || !phone.trim() || !email.trim() || !date.trim()) {
      Alert.alert('Chybí údaje', 'Vyplň jméno, telefon, e-mail a datum převzetí.'); return;
    }
    if (rate === 2 && new Date(date + 'T12:00:00').getDay() !== 5) {
      Alert.alert('Víkendová rezervace', 'Víkendové půjčení začíná v pátek.'); return;
    }
    const payload = {
      trailer_id: trailer, rental_type: rates[rate].label, price_czk: rates[rate].price,
      pickup_date: date, pickup_time: time, customer_name: name.trim(),
      customer_phone: phone.trim(), customer_email: email.trim(),
      payment_method: payment, status: 'pending'
    };
    if (!supabase) {
      Alert.alert('Demo režim', 'Aplikace ještě není připojena k online databázi. Žádost nebyla odeslána.'); return;
    }
    const { error } = await supabase.from('reservations').insert(payload);
    if (error) { Alert.alert('Chyba rezervace', error.message); return; }
    Alert.alert('Žádost odeslána', 'Děkujeme. Rezervaci potvrdíme po kontrole dostupnosti.');
    setTab('home'); loadRequests();
  }
  async function updateStatus(id: string, status: string) {
    if (!supabase) { Alert.alert('Demo režim', 'Nejdříve připoj databázi.'); return; }
    const { error } = await supabase.from('reservations').update({ status }).eq('id', id);
    if (error) Alert.alert('Chyba', error.message); else loadRequests();
  }
  const button = (label: string, onPress: () => void, outline = false) => <TouchableOpacity onPress={onPress} style={{backgroundColor:outline?PANEL:Y,borderWidth:outline?1:0,borderColor:'#555',padding:14,borderRadius:10,marginTop:9}}><Text style={{color:outline?'white':'#111',fontWeight:'800',textAlign:'center'}}>{label}</Text></TouchableOpacity>;
  const field = (label: string, value: string, set: (s:string)=>void, placeholder: string, keyboardType:any='default') => <View style={{marginTop:12}}><Text style={{color:'#ccc',marginBottom:5}}>{label}</Text><TextInput value={value} onChangeText={set} placeholder={placeholder} placeholderTextColor="#888" keyboardType={keyboardType} style={{backgroundColor:'#292929',borderColor:'#555',borderWidth:1,borderRadius:9,padding:12,color:'white'}} /></View>;
  const panel = (children: React.ReactNode) => <View style={{backgroundColor:PANEL,borderColor:'#393939',borderWidth:1,borderRadius:14,padding:14,marginBottom:12}}>{children}</View>;
  const heading = (s:string) => <Text style={{fontSize:23,fontWeight:'900',color:'white',marginBottom:14}}>{s}</Text>;

  return <SafeAreaView style={{flex:1,backgroundColor:BG}}>
    <StatusBar barStyle="light-content" />
    <View style={{padding:17,borderBottomWidth:1,borderColor:'#333',flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>
      <View><Text style={{fontSize:24,fontWeight:'900',color:Y,letterSpacing:2}}>VOTICE</Text><Text style={{color:MUTED,fontSize:10,letterSpacing:2}}>PŮJČOVNA VOZÍKŮ</Text></View>
      <TouchableOpacity onPress={()=>Linking.openURL('tel:725186541')}><Text style={{color:Y,fontWeight:'700'}}>☎ 725 186 541</Text></TouchableOpacity>
    </View>
    <ScrollView style={{flex:1}} contentContainerStyle={{padding:16,paddingBottom:25}}>
      {tab==='home' && <>
        <View style={{backgroundColor:'#292313',padding:20,borderRadius:15,marginBottom:18}}>
          <Text style={{color:Y,fontWeight:'800'}}>VOTICE A OKOLÍ</Text><Text style={{fontSize:30,fontWeight:'900',color:'white',marginTop:10}}>Potřebuješ něco převézt?</Text><Text style={{color:'#ddd',marginTop:8}}>Vyber si vozík a pošli nám žádost o rezervaci.</Text>{button('VYBRAT VOZÍK →',()=>setTab('trailers'))}
        </View>
        {heading('Ceník')}
        <View style={{flexDirection:'row',gap:7}}>{rates.map(r=><View key={r.label} style={{flex:1,backgroundColor:PANEL,padding:10,borderRadius:10}}><Text style={{color:Y,fontWeight:'900',fontSize:18}}>{r.price} Kč</Text><Text style={{color:MUTED,fontSize:11}}>{r.label}</Text></View>)}</View>
        <View style={{marginTop:18}}>{panel(<><Text style={{color:'white',fontWeight:'800'}}>Bez kauce • Platba při převzetí</Text><Text style={{color:MUTED,marginTop:5}}>Hotově nebo bankovním převodem. Každou rezervaci osobně potvrzujeme.</Text></>)}</View>
      </>}
      {tab==='trailers' && <>{heading('Naše vozíky')}{trailers.map(t=>panel(<><View style={{flexDirection:'row',justifyContent:'space-between'}}><Text style={{fontSize:20,fontWeight:'900',color:'white'}}>{t.name}</Text><Text style={{color:Y,fontWeight:'800'}}>{t.capacity}</Text></View><Text style={{color:MUTED,marginTop:6}}>Ložná plocha {t.dimensions}</Text>{button('REZERVOVAT',()=>{setTrailer(t.id);setTab('booking')})}</>))}</>}
      {tab==='booking' && <>{heading('Žádost o rezervaci')}
        <Text style={{color:MUTED}}>Vyplň údaje. Termín platí až po našem potvrzení.</Text>
        <Text style={{color:'#ccc',marginTop:14}}>Vozík</Text>{trailers.map(t=>button(t.name+(trailer===t.id?' ✓':''),()=>setTrailer(t.id),trailer!==t.id))}
        <Text style={{color:'#ccc',marginTop:14}}>Doba půjčení</Text>{rates.map((r,i)=>button(`${r.label} – ${r.price} Kč${rate===i?' ✓':''}`,()=>setRate(i),rate!==i))}
        {field('Datum převzetí (RRRR-MM-DD)',date,setDate,'2026-12-01')}
        {field('Čas převzetí',time,setTime,'09:00')}
        {field('Jméno a příjmení',name,setName,'Jméno')}
        {field('Telefon',phone,setPhone,'Telefon','phone-pad')}
        {field('E-mail',email,setEmail,'vas@email.cz','email-address')}
        <Text style={{color:'#ccc',marginTop:14}}>Platba</Text>{button('Hotově při převzetí',()=>setPayment('Hotově při převzetí'),payment!=='Hotově při převzetí')}{button('Bankovním převodem při převzetí',()=>setPayment('Bankovním převodem při převzetí'),payment!=='Bankovním převodem při převzetí')}
        <View style={{marginTop:15}}>{panel(<><Text style={{color:MUTED}}>Cena</Text><Text style={{color:Y,fontSize:25,fontWeight:'900'}}>{rates[rate].price} Kč</Text><Text style={{color:MUTED}}>Bez kauce</Text></>)}</View>
        {button('ODESLAT ŽÁDOST',submit)}
      </>}
      {tab==='admin' && <>{heading('Administrace')}<View style={{backgroundColor:connected?'#183522':'#392d12',padding:12,borderRadius:10,marginBottom:12}}><Text style={{color:connected?'#8be0a4':Y,fontWeight:'800'}}>{connected?'Databáze připojena':'Databáze zatím není připojena'}</Text><Text style={{color:'#ddd',fontSize:12,marginTop:4}}>Administrace je určena pouze majiteli. Před ostrým provozem doplníme bezpečné přihlášení.</Text></View>{button('OBNOVIT REZERVACE',loadRequests,true)}{requests.length===0?<Text style={{color:MUTED,marginTop:15}}>Žádné načtené rezervace.</Text>:requests.map(r=>panel(<><Text style={{color:Y,fontWeight:'900'}}>{r.trailer_id} · {r.price_czk} Kč</Text><Text style={{color:'white',marginTop:5}}>{r.customer_name} · {r.customer_phone}</Text><Text style={{color:MUTED}}>{r.pickup_date} {r.pickup_time} · {r.rental_type}</Text><Text style={{color:MUTED}}>{r.status}</Text>{r.status==='pending'&&<>{button('POTVRDIT',()=>updateStatus(r.id,'confirmed'))}{button('ZAMÍTNOUT',()=>updateStatus(r.id,'rejected'),true)}</>}</>))}</>}
    </ScrollView>
    <View style={{flexDirection:'row',borderTopWidth:1,borderColor:'#333',backgroundColor:'#191919'}}>
      {(['home','trailers','booking','admin'] as const).map((t,i)=><TouchableOpacity key={t} onPress={()=>setTab(t)} style={{flex:1,padding:12,alignItems:'center',borderTopWidth:tab===t?3:0,borderColor:Y}}><Text style={{color:tab===t?Y:'#aaa',fontSize:11,fontWeight:'700'}}>{['⌂ DOMŮ','▤ VOZÍKY','＋ REZERVACE','⚙ SPRÁVA'][i]}</Text></TouchableOpacity>)}
    </View>
  </SafeAreaView>;
}
