-- Run this in the Supabase SQL Editor after creating your project.
create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(),
  trailer_id text not null check (trailer_id in ('neptun','agados')),
  rental_type text not null,
  price_czk integer not null check (price_czk in (200,300,450)),
  pickup_date date not null,
  pickup_time time not null,
  customer_name text not null,
  customer_phone text not null,
  customer_email text not null,
  payment_method text not null check (payment_method in ('Hotově při převzetí','Bankovním převodem při převzetí')),
  status text not null default 'pending' check (status in ('pending','confirmed','rejected')),
  created_at timestamptz not null default now()
);

-- Do not enable public read/write policies for a production rental app.
-- Before launch, configure authenticated customer booking inserts and owner-only
-- reads/updates using Supabase Auth + Row Level Security policies.
alter table public.reservations enable row level security;
