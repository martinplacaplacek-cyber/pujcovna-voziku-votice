import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

// Until the owner creates a Supabase project and adds the public client settings,
// the app deliberately stays in demo mode and does not pretend to submit bookings.
export const supabase = url && key ? createClient(url, key) : null;
